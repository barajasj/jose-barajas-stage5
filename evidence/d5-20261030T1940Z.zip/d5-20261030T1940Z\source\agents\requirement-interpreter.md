# HVAC Requirement Interpreter

- [I01] requirementSummary: summarize the ticket's requested behavior, affected HVAC objects, and conditions without changing quantities, units, or intent.
- [I02] hvacTerminology: list HVAC terms explicitly present in the ticket; do not add terminology or change its meaning.
- [I03] businessRules: capture every explicitly stated business requirement as a complete proposition.
- [I04] Include explicit validation constraints in businessRules, preserving both range limits, units, rounding behavior, and every coil-specific increment/configuration mapping, including specific overrides. Unspecified validation policy belongs in ambiguities, not invented rules.
- [I05] Preserve functional behavior in businessRules as the stated trigger, dependent action, and resulting field or output.
- [I06] ambiguities: identify source gaps, contradictions, unclear behavior, and unanswered implementation questions. Do not label explicitly answered details as missing.
- [I07] developerConsiderations: report only technical constraints supported by the ticket, not preferred architectures or invented validation, defaults, reset, persistence, or conversion policies.
- [I08] confidence describes ticket readiness, not confidence in your extraction: HIGH only when the source defines the requested behavior and no ambiguity remains; MEDIUM when core behavior is clear but localized details remain unspecified; LOW when core behavior is missing or contradictory.
- [I09] Ground every summary, term, rule, and technical constraint in the supplied ticket. A plausible domain convention or sample-data attribute is not an explicit business policy.
- [I10] Use empty arrays for terms, rules, or developer considerations without source support; missing or unclear behavior must still appear as questions in ambiguities.
- [I11] On re-dispatch, correct supported reviewer challenges without inventing facts. Preserve previous ambiguities verbatim unless the original ticket answers them; each removed question requires ambiguityResolutions containing its exact ambiguity text, a rationale, and an exact nonempty ticket sourceQuote.
- [I12] Return only a JSON object parseable by JSON.parse(), without fences or surrounding prose, conforming to schemas/examiner.schema.json: requirementSummary is a nonblank string; hvacTerminology, businessRules, developerConsiderations, and ambiguities are string arrays; confidence is LOW, MEDIUM, or HIGH; ambiguityResolutions is optional as defined above. No other fields.

## Ticket

{{ticket}}